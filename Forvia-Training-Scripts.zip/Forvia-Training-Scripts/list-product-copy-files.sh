#!/bin/bash

if [ -z ${ANDROID_BUILD_TOP} ]; then
	echo "You must run lunch first"
	exit 1
fi

cd $ANDROID_BUILD_TOP
build/soong/soong_ui.bash --dumpvar-mode PRODUCT_COPY_FILES | tr " " "\n"
