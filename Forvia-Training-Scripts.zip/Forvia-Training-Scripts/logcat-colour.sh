#!/bin/bash
adb logcat -v color
