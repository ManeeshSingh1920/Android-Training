#!/bin/bash

# List product packages

if [ -z ${ANDROID_BUILD_TOP} ]; then
	echo "You must run lunch first"
	exit 1
fi

VERBOSE=1

if [ $# == 1 ]; then
 case $1 in
	 "-b")
		VERBOSE=0
		;;
	"-h")
		echo "usage"
		echo "$0 [-h -b]"
		echo "  -h   this help text"
		echo "  -b   brief - no section headings"

		exit
		;;
 esac
fi

cd $ANDROID_BUILD_TOP

if [ $VERBOSE == 1 ]; then
 echo "Packages in all builds"
 echo "(PRODUCT_PACKAGES):"
 echo "----------------------------------------"
fi
build/soong/soong_ui.bash --dumpvar-mode PRODUCT_PACKAGES | tr " " "\n"

if [ $VERBOSE == 1 ]; then
 echo "-----------------------------------------------"
 echo "Additional packages in userdebug and eng builds"
 echo "(PRODUCT_PACKAGES_DEBUG):"
 echo "-----------------------------------------------"
fi
build/soong/soong_ui.bash --dumpvar-mode PRODUCT_PACKAGES_DEBUG | tr " " "\n"

if [ $VERBOSE == 1 ]; then
 echo "-----------------------------------------------"
 echo "Additional packages in eng build"
 echo "(PRODUCT_PACKAGES_ENG):"
 echo "-----------------------------------------------"
fi
build/soong/soong_ui.bash --dumpvar-mode PRODUCT_PACKAGES_ENG | tr " " "\n"

if [ $VERBOSE == 1 ]; then
 echo "-----------------------------------------------"
fi
