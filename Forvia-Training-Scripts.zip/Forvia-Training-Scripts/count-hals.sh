#!/bin/bash

cd $ANDROID_BUILD_TOP/hardware/interfaces

# Look for HIDL interfaces of the form ISomehal.hal
TYPES_HAL=$(find -name 'I*.hal')

for h in $TYPES_HAL; do
	# strip off "I*.hal" and the "N.M" directory
	BASE_HIDL+=$(dirname $(dirname $h) )
	BASE_HIDL+=$'\n'
done

# Strip out duplicate directories, which you get from somehal/1.0/types.hal, somehal/2.0/types.hal, ...
UNIQ_HIDL_HALS=$(echo $BASE_HIDL | tr " " "\n" | uniq )

#echo "Number of HIDL HALs"
#echo $UNIQ_HIDL_HALS | wc -w

# Every AIDL HAL is in directory named aidl
AIDL_HALS=$(find -name aidl)

#echo "Number of aidl directories"
#echo $AIDL_HALS | wc -w

for f in $AIDL_HALS; do
	# strip off the 'aidl' part
	BASE_AIDL+=$(dirname $f)
	BASE_AIDL+=$'\n'
done

UNIQ_AIDL_HALS=$(echo $BASE_AIDL | tr " " "\n" | uniq )
#echo "uniq AIDL HALs"
#echo $UNIQ_AIDL_HALS

#echo "Number of AIDL HALs"
#echo $UNIQ_AIDL_HALS | wc -w

# Find HIDL HALs that do not have an AIDL equivalent
NUM_HIDL_ONLY=0
for h in $UNIQ_HIDL_HALS; do
	if ! grep -q $h <<<"$UNIQ_AIDL_HALS"; then
		echo "$h HIDL only"
		NUM_HIDL_ONLY=$(expr $NUM_HIDL_ONLY + 1)
	fi
done
echo "------"

# Find AIDL HALs that do not have an HIDL equivalent
NUM_AIDL_ONLY=0
for h in $UNIQ_AIDL_HALS; do
#	echo "h = $h"
	if ! grep -q $h <<<"$UNIQ_HIDL_HALS"; then
		echo "$h AIDL only"
		NUM_AIDL_ONLY=$(expr $NUM_AIDL_ONLY + 1)
	fi
done
echo "------"

echo 
echo -n "Number of HIDL HALs: "
echo $UNIQ_HIDL_HALS | wc -w
echo -n "Number of AIDL HALs: "
echo $UNIQ_AIDL_HALS | wc -w
echo "Number of HIDL only HALS: $NUM_HIDL_ONLY" 
echo "Number of AIDL only HALS: $NUM_AIDL_ONLY" 
