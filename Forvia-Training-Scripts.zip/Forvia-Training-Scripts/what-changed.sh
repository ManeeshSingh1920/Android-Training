#!/bin/bash

if [ $# -eq 2 ]; then
	FIRST_TAG=$1
	SECOND_TAG=$2
	SHOW_DIFF=false
elif [ $# -eq 3 ]; then
	FIRST_TAG=$2
	SECOND_TAG=$3
	SHOW_DIFF=true
else
	echo "Print the projects that have changed between two git tags"
	echo "Usage 1: $0 first-tag second-tag"
	echo "Usage 2: $0 -diff first-tag second-tag"
	exit 0
fi

# Check that the first tag is a branch in this repo
REPOCMD="if ! git tag | grep ${FIRST_TAG} 2>&1 > /dev/null; then "
REPOCMD+='echo -n $REPO_PATH;'
REPOCMD+="echo -n ' does NOT contain '"
REPOCMD+="${FIRST_TAG};"
REPOCMD+="elif ! git diff --exit-code --quiet ${FIRST_TAG}..${SECOND_TAG} 2>&1 > /dev/null;then "
REPOCMD+='echo $REPO_PATH;'
if ${SHOW_DIFF}; then
	REPOCMD+="git diff ${FIRST_TAG}..${SECOND_TAG};"
fi
REPOCMD+="fi"

# echo $REPOCMD

repo forall -c "$REPOCMD"


